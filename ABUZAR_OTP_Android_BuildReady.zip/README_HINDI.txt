ABUZAR OTP — Android Source Project + Cloud APK Build

यह APK सीधे ZIP से install नहीं होता। यह Android Studio/Gradle से build होने वाला source project है।

फोन से APK बनवाने का आसान cloud तरीका:
1. GitHub पर नया repository बनाएं (Public या Private)।
2. इस ZIP को Extract करके इसके अंदर की सभी फाइलें repository में upload करें।
   ध्यान दें: .github नाम का hidden folder भी upload होना चाहिए।
3. GitHub repository में Actions tab खोलें।
4. “Build ABUZAR OTP APK” workflow चुनकर Run workflow दबाएं।
5. Build पूरा होने पर run खोलें और नीचे Artifacts में ABUZAR-OTP-debug-apk डाउनलोड करें।
6. ZIP artifact Extract करें। app-debug.apk पर tap करके Android install prompt follow करें।
7. Android Unknown app install permission पूछे तो केवल GitHub से डाउनलोड की अपनी build के लिए अनुमति दें।

ऐप का व्यवहार:
- “Listen for one SMS (5 minutes)” दबाने पर Android SMS User Consent API एक eligible SMS के लिए प्रतीक्षा करती है।
- SMS मिलने पर Google/Android consent dialog दिखाता है। Allow करने पर संदेश ऐप में दिखता है।
- यह पूरे inbox को नहीं पढ़ता, लगातार background में SMS नहीं पढ़ता और SMS server पर upload नहीं करता।
- हर sender/message eligible नहीं होता। Google Play services आवश्यक हैं।
- केवल अपने खाते के OTP इस्तेमाल करें।

Build config: Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17.
