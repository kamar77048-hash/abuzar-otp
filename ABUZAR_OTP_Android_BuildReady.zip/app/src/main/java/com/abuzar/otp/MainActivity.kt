package com.abuzar.otp

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Status

class MainActivity : ComponentActivity() {
    private lateinit var statusText: TextView
    private lateinit var smsText: TextView
    private var receiverRegistered = false

    private val consentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val message = result.data!!.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE).orEmpty()
            smsText.text = message.ifBlank { "No message text returned." }
            statusText.text = "Message received with your approval. It stays on this phone."
        } else {
            statusText.text = "You declined or cancelled SMS access. No message was read."
        }
    }

    private val smsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (SmsRetriever.SMS_RETRIEVED_ACTION != intent.action) return
            val extras = intent.extras ?: return
            val status = extras.get(SmsRetriever.EXTRA_STATUS) as? Status ?: return
            when (status.statusCode) {
                CommonStatusCodes.SUCCESS -> {
                    val consentIntent = extras.getParcelable<Intent>(SmsRetriever.EXTRA_CONSENT_INTENT)
                    if (consentIntent != null) consentLauncher.launch(consentIntent)
                }
                CommonStatusCodes.TIMEOUT -> statusText.text =
                    "No matching SMS arrived within 5 minutes. Tap Listen again."
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        registerSmsReceiver()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(0xFF080B13.toInt())
        }
        val title = TextView(this).apply {
            text = "ABUZAR OTP"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(0xFFF4F7FF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Private, consent-based OTP viewer"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF9AA8C0.toInt())
            setPadding(0, 8, 0, 24)
        }
        statusText = TextView(this).apply {
            text = "Tap Listen for OTP, then approve the Google SMS consent prompt."
            textSize = 15f
            setTextColor(0xFFBFCBE0.toInt())
            setPadding(0, 12, 0, 18)
        }
        val listen = Button(this).apply {
            text = "Listen for one SMS (5 minutes)"
            setOnClickListener { startListening() }
        }
        smsText = TextView(this).apply {
            text = "No SMS received."
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(16, 20, 16, 20)
            setBackgroundColor(0xFF151E30.toInt())
        }
        val warning = TextView(this).apply {
            text = "Privacy: this app does not read the inbox, run in the background, upload messages, or send OTPs to a website. Android/Google shows a consent prompt before the selected SMS is shared with this app. Only use codes for accounts you own."
            textSize = 12f
            setTextColor(0xFF9AA8C0.toInt())
            setPadding(0, 22, 0, 0)
        }
        root.addView(title, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(subtitle)
        root.addView(listen, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(statusText)
        root.addView(smsText, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(warning)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun startListening() {
        smsText.text = "Waiting for one eligible SMS…"
        statusText.text = "Listening for up to 5 minutes. A consent prompt will appear if a message qualifies."
        SmsRetriever.getClient(this).startSmsUserConsent(null)
            .addOnSuccessListener { statusText.text = "Listening. Wait for the SMS and approve the consent prompt." }
            .addOnFailureListener { statusText.text = "Could not start SMS consent. Check Google Play services and try again." }
    }

    private fun registerSmsReceiver() {
        val filter = IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION)
        ContextCompat.registerReceiver(
            this, smsReceiver, filter, ContextCompat.RECEIVER_EXPORTED
        )
        receiverRegistered = true
    }

    override fun onDestroy() {
        if (receiverRegistered) unregisterReceiver(smsReceiver)
        super.onDestroy()
    }

    private fun match(width: Int, height: Int) =
        LinearLayout.LayoutParams(width, height).apply { bottomMargin = 16 }
}
